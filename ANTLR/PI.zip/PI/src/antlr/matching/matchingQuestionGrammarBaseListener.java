package antlr.matching;// Generated from C:/Users/0941p/OneDrive/Ambiente de Trabalho/ISEP/ISEP_2�ano/2�Semestre/LPROG/ANTLR/Ex1\matchingQuestionGrammar.g4 by ANTLR 4.12.0

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

/**
 * This class provides an empty implementation of {@link matchingQuestionGrammarListener},
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
@SuppressWarnings("CheckReturnValue")
public class matchingQuestionGrammarBaseListener implements matchingQuestionGrammarListener {
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMatchingQuestion(matchingQuestionGrammarParser.MatchingQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMatchingQuestion(matchingQuestionGrammarParser.MatchingQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMatchingQuestion_questionText(matchingQuestionGrammarParser.MatchingQuestion_questionTextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMatchingQuestion_questionText(matchingQuestionGrammarParser.MatchingQuestion_questionTextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMatchingQuestion_subQuestions(matchingQuestionGrammarParser.MatchingQuestion_subQuestionsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMatchingQuestion_subQuestions(matchingQuestionGrammarParser.MatchingQuestion_subQuestionsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMatchingQuestion_subQuestion(matchingQuestionGrammarParser.MatchingQuestion_subQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMatchingQuestion_subQuestion(matchingQuestionGrammarParser.MatchingQuestion_subQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMatchingQuestion_answers(matchingQuestionGrammarParser.MatchingQuestion_answersContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMatchingQuestion_answers(matchingQuestionGrammarParser.MatchingQuestion_answersContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMatchingQuestion_answer(matchingQuestionGrammarParser.MatchingQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMatchingQuestion_answer(matchingQuestionGrammarParser.MatchingQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMultipleChoiceQuestion(matchingQuestionGrammarParser.MultipleChoiceQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMultipleChoiceQuestion(matchingQuestionGrammarParser.MultipleChoiceQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMultipleChoiceQuestion_questionText(matchingQuestionGrammarParser.MultipleChoiceQuestion_questionTextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMultipleChoiceQuestion_questionText(matchingQuestionGrammarParser.MultipleChoiceQuestion_questionTextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMultipleChoiceQuestion_options(matchingQuestionGrammarParser.MultipleChoiceQuestion_optionsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMultipleChoiceQuestion_options(matchingQuestionGrammarParser.MultipleChoiceQuestion_optionsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMultipleChoiceQuestion_option(matchingQuestionGrammarParser.MultipleChoiceQuestion_optionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMultipleChoiceQuestion_option(matchingQuestionGrammarParser.MultipleChoiceQuestion_optionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMultipleChoiceQuestion_optionText(matchingQuestionGrammarParser.MultipleChoiceQuestion_optionTextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMultipleChoiceQuestion_optionText(matchingQuestionGrammarParser.MultipleChoiceQuestion_optionTextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortAnswerQuestion(matchingQuestionGrammarParser.ShortAnswerQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortAnswerQuestion(matchingQuestionGrammarParser.ShortAnswerQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortAnswerQuestion_question(matchingQuestionGrammarParser.ShortAnswerQuestion_questionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortAnswerQuestion_question(matchingQuestionGrammarParser.ShortAnswerQuestion_questionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortAnswerQuestion_answer(matchingQuestionGrammarParser.ShortAnswerQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortAnswerQuestion_answer(matchingQuestionGrammarParser.ShortAnswerQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNumericalQuestion(matchingQuestionGrammarParser.NumericalQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNumericalQuestion(matchingQuestionGrammarParser.NumericalQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNumericalQuestion_question(matchingQuestionGrammarParser.NumericalQuestion_questionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNumericalQuestion_question(matchingQuestionGrammarParser.NumericalQuestion_questionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNumericalQuestion_answer(matchingQuestionGrammarParser.NumericalQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNumericalQuestion_answer(matchingQuestionGrammarParser.NumericalQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNumericalQuestion_error(matchingQuestionGrammarParser.NumericalQuestion_errorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNumericalQuestion_error(matchingQuestionGrammarParser.NumericalQuestion_errorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMissingWordQuestion(matchingQuestionGrammarParser.MissingWordQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMissingWordQuestion(matchingQuestionGrammarParser.MissingWordQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMissingWordQuestion_lines(matchingQuestionGrammarParser.MissingWordQuestion_linesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMissingWordQuestion_lines(matchingQuestionGrammarParser.MissingWordQuestion_linesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMissingWordQuestion_sentence(matchingQuestionGrammarParser.MissingWordQuestion_sentenceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMissingWordQuestion_sentence(matchingQuestionGrammarParser.MissingWordQuestion_sentenceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMissingWordQuestion_answer(matchingQuestionGrammarParser.MissingWordQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMissingWordQuestion_answer(matchingQuestionGrammarParser.MissingWordQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMissingWordQuestion_options(matchingQuestionGrammarParser.MissingWordQuestion_optionsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMissingWordQuestion_options(matchingQuestionGrammarParser.MissingWordQuestion_optionsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTrueFalseQuestion(matchingQuestionGrammarParser.TrueFalseQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTrueFalseQuestion(matchingQuestionGrammarParser.TrueFalseQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTrueFalseQuestion_sentence(matchingQuestionGrammarParser.TrueFalseQuestion_sentenceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTrueFalseQuestion_sentence(matchingQuestionGrammarParser.TrueFalseQuestion_sentenceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTrueFalseQuestion_anwser(matchingQuestionGrammarParser.TrueFalseQuestion_anwserContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTrueFalseQuestion_anwser(matchingQuestionGrammarParser.TrueFalseQuestion_anwserContext ctx) { }

	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterEveryRule(ParserRuleContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitEveryRule(ParserRuleContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void visitTerminal(TerminalNode node) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void visitErrorNode(ErrorNode node) { }
}