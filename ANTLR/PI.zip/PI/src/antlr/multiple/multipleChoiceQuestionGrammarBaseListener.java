package antlr.multiple;// Generated from C:/Users/0941p/OneDrive/Ambiente de Trabalho/ISEP/ISEP_2�ano/2�Semestre/LPROG/ANTLR/Ex1\multipleChoiceQuestionGrammar.g4 by ANTLR 4.12.0

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

/**
 * This class provides an empty implementation of {@link multipleChoiceQuestionGrammarListener},
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
@SuppressWarnings("CheckReturnValue")
public class multipleChoiceQuestionGrammarBaseListener implements multipleChoiceQuestionGrammarListener {
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMultipleChoiceQuestion(multipleChoiceQuestionGrammarParser.MultipleChoiceQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMultipleChoiceQuestion(multipleChoiceQuestionGrammarParser.MultipleChoiceQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMultipleChoiceQuestion_questionText(multipleChoiceQuestionGrammarParser.MultipleChoiceQuestion_questionTextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMultipleChoiceQuestion_questionText(multipleChoiceQuestionGrammarParser.MultipleChoiceQuestion_questionTextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMultipleChoiceQuestion_options(multipleChoiceQuestionGrammarParser.MultipleChoiceQuestion_optionsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMultipleChoiceQuestion_options(multipleChoiceQuestionGrammarParser.MultipleChoiceQuestion_optionsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMultipleChoiceQuestion_option(multipleChoiceQuestionGrammarParser.MultipleChoiceQuestion_optionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMultipleChoiceQuestion_option(multipleChoiceQuestionGrammarParser.MultipleChoiceQuestion_optionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMultipleChoiceQuestion_optionText(multipleChoiceQuestionGrammarParser.MultipleChoiceQuestion_optionTextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMultipleChoiceQuestion_optionText(multipleChoiceQuestionGrammarParser.MultipleChoiceQuestion_optionTextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortAnswerQuestion(multipleChoiceQuestionGrammarParser.ShortAnswerQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortAnswerQuestion(multipleChoiceQuestionGrammarParser.ShortAnswerQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortAnswerQuestion_question(multipleChoiceQuestionGrammarParser.ShortAnswerQuestion_questionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortAnswerQuestion_question(multipleChoiceQuestionGrammarParser.ShortAnswerQuestion_questionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortAnswerQuestion_answer(multipleChoiceQuestionGrammarParser.ShortAnswerQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortAnswerQuestion_answer(multipleChoiceQuestionGrammarParser.ShortAnswerQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNumericalQuestion(multipleChoiceQuestionGrammarParser.NumericalQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNumericalQuestion(multipleChoiceQuestionGrammarParser.NumericalQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNumericalQuestion_question(multipleChoiceQuestionGrammarParser.NumericalQuestion_questionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNumericalQuestion_question(multipleChoiceQuestionGrammarParser.NumericalQuestion_questionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNumericalQuestion_answer(multipleChoiceQuestionGrammarParser.NumericalQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNumericalQuestion_answer(multipleChoiceQuestionGrammarParser.NumericalQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNumericalQuestion_error(multipleChoiceQuestionGrammarParser.NumericalQuestion_errorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNumericalQuestion_error(multipleChoiceQuestionGrammarParser.NumericalQuestion_errorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMissingWordQuestion(multipleChoiceQuestionGrammarParser.MissingWordQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMissingWordQuestion(multipleChoiceQuestionGrammarParser.MissingWordQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMissingWordQuestion_lines(multipleChoiceQuestionGrammarParser.MissingWordQuestion_linesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMissingWordQuestion_lines(multipleChoiceQuestionGrammarParser.MissingWordQuestion_linesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMissingWordQuestion_sentence(multipleChoiceQuestionGrammarParser.MissingWordQuestion_sentenceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMissingWordQuestion_sentence(multipleChoiceQuestionGrammarParser.MissingWordQuestion_sentenceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMissingWordQuestion_answer(multipleChoiceQuestionGrammarParser.MissingWordQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMissingWordQuestion_answer(multipleChoiceQuestionGrammarParser.MissingWordQuestion_answerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMissingWordQuestion_options(multipleChoiceQuestionGrammarParser.MissingWordQuestion_optionsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMissingWordQuestion_options(multipleChoiceQuestionGrammarParser.MissingWordQuestion_optionsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTrueFalseQuestion(multipleChoiceQuestionGrammarParser.TrueFalseQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTrueFalseQuestion(multipleChoiceQuestionGrammarParser.TrueFalseQuestionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTrueFalseQuestion_sentence(multipleChoiceQuestionGrammarParser.TrueFalseQuestion_sentenceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTrueFalseQuestion_sentence(multipleChoiceQuestionGrammarParser.TrueFalseQuestion_sentenceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTrueFalseQuestion_anwser(multipleChoiceQuestionGrammarParser.TrueFalseQuestion_anwserContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTrueFalseQuestion_anwser(multipleChoiceQuestionGrammarParser.TrueFalseQuestion_anwserContext ctx) { }

	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterEveryRule(ParserRuleContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitEveryRule(ParserRuleContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void visitTerminal(TerminalNode node) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void visitErrorNode(ErrorNode node) { }
}