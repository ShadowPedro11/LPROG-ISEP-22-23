package main;


import antlr.exam.examGrammarLexer;
import antlr.exam.examGrammarParser;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTreeWalker;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ExamMain {



    public static void main(String[] args) {
        String filename = "src/question/exam"; // Specify the path to your file here
        Path path = Paths.get(filename);


        try {
            String input = new String(Files.readAllBytes(path));

            examGrammarLexer lexer = new examGrammarLexer(CharStreams.fromString(input));
            CommonTokenStream tokens = new CommonTokenStream(lexer);
            examGrammarParser parser = new examGrammarParser(tokens);

            examGrammarParser.ExamContext examContext = parser.exam();

            if (parser.getNumberOfSyntaxErrors() == 0) {
                Listener listener = new Listener();
                ParseTreeWalker walker = new ParseTreeWalker();
                walker.walk(listener, examContext);
            } else {
                System.out.println("Invalid Exam");
            }






        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }


}
