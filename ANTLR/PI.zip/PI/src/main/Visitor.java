package main;

import antlr.exam.examGrammarBaseVisitor;
import antlr.exam.examGrammarParser;

public class Visitor extends examGrammarBaseVisitor {

    String title;


    @Override
    public Void visitTitle(examGrammarParser.TitleContext ctx) {
        title = ctx.STRING().getText();
        return null;
    }

    public String getTitle() {
        return title;
    }
}
